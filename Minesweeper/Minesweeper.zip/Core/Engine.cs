﻿namespace Minesweeper.Core
{
    using System;


    using Contracts;
    using Build.Contracts;
    using Minesweeper.Build;
    using Minesweeper.IO.Contracts;
    using Minesweeper.Data.Uttilites.Exceptions;

    internal class Engine : IEngine
    {
        private IMesh _mesh;
        private const string Difficulty = "easy";
        private IWriter _writer;
        private IReader _reader;
        public Engine(IMesh mesh, IWriter writer, IReader reader)//dependancy ingections
        {
            this._mesh = mesh;
            this._reader = reader;
            this._writer = writer;
        }

        public void Start()
        {
            //reset
            //ask for difficulty
            this._mesh.SetGameArea();
            this._mesh.CalucateBombsByDifficulty(Difficulty);
            this._mesh.PlantBombs();

            this._writer.Write(this._mesh.GetGameArea());


            while (true)
            {
                try
                {
                    ICoordinates coordinatesSelectedByUser = GetCordinates();

                    this._writer.WriteLine("Enter /m to select the cell as marked bomb or enter /e to explore the cell:");
                    string input = this._reader.ReadLine();
                    if (input.ToLower() == "/m")
                    {
                        this._mesh.MarkCellAsABomb(coordinatesSelectedByUser);
                        this._writer.WriteLine($"You have marked cell [{coordinatesSelectedByUser.X}][{coordinatesSelectedByUser.Y}] as bomb.");

                        this._writer.Write(this._mesh.GetGameArea());
                    }
                    else if (input.ToLower() == "/e")
                    {
                        this._mesh.ExploreCell(coordinatesSelectedByUser);
                        this._writer.Write(this._mesh.GetGameArea());
                    }
                }
                catch (GameEndedException gameEndedException)
                {
                    this._writer.WriteLine(gameEndedException.Message);
                    //this._writer.WriteLine(this._mesh.Stats());
                }
                catch (Exception)
                {

                    throw;
                }
            }
        }

        private ICoordinates GetCordinates()
        {
            this._writer.Write("Enter 'X' - coordinate:");
            int x = int.Parse(this._reader.ReadLine());

            this._writer.Write("Enter 'Y' - coordinate:");
            int y = int.Parse(this._reader.ReadLine());

            ICoordinates coordinatesSelectedByUser = new Coordinates(x, y);
            return coordinatesSelectedByUser;
        }
    }
}
