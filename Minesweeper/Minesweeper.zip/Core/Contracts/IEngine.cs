﻿namespace Minesweeper.Core.Contracts
{
    internal interface IEngine
    {
        public void Start();
    }
}
