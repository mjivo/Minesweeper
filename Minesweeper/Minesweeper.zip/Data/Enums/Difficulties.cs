﻿namespace Minesweeper.Data.Enums
{
    internal enum Difficulties
    {
        easy = 15,
        medium = 28,
        hard = 32,
        verryHard = 35,
        unplayable = 45,
    }
}
