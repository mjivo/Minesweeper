﻿namespace Minesweeper.IO.Contracts
{
    internal interface IReader
    {
        public string ReadLine();
    }
}
